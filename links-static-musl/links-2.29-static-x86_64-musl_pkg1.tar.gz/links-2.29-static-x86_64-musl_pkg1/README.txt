Links 2.29 + OpenSSL 3.5.4 + zlib 1.3.1, static musl build (x86_64), package pkg1.
Run ./links-color https://example.org     (use the wrapper: it supplies the CA file)
Guides are in docs/. Built by build_links_static_v1.sh.
Source sha256:
  links 2.29     22aa96c0b38e1a6f8f7ed9d7a4167a47fc37246097759ef6059ecf8f9ead7998
  openssl 3.5.4  967311f84955316969bdb1d8d4b983718ef42338639c621ec4c34fddef355e99
  zlib 1.3.1        9a93b2b7dfdac77ceba5a558a580e74667dd6fede4585b91eefb60f03b72df23
  cacert.pem (113 roots) bb92c6ac31c92f4f553bffd6bf093db02c858c23e111b0b4df9bafa3fdbe00d1
